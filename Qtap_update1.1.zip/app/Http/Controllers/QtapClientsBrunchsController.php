<?php

namespace App\Http\Controllers;

use App\Models\qtap_clients_brunchs;
use Illuminate\Http\Request;

class QtapClientsBrunchsController extends Controller
{

    public function index()
    {
        //
    }


    public function store(Request $request)
    {
        //
    }


    public function update(Request $request, qtap_clients_brunchs $qtap_clients_brunchs)
    {
        //
    }


    public function destroy(qtap_clients_brunchs $qtap_clients_brunchs)
    {
        //
    }
}
