<?php

namespace App\Http\Controllers;

use App\Models\clients_logs;
use Illuminate\Http\Request;

class ClientsLogsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(clients_logs $clients_logs)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(clients_logs $clients_logs)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, clients_logs $clients_logs)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(clients_logs $clients_logs)
    {
        //
    }
}
