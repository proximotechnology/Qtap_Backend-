<?php

namespace App\Http\Controllers;

use App\Models\serving_ways;
use Illuminate\Http\Request;

class ServingWaysController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(serving_ways $serving_ways)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(serving_ways $serving_ways)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, serving_ways $serving_ways)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(serving_ways $serving_ways)
    {
        //
    }
}
